<?php
include "PHPMailer/src/PHPMailer.php";
include "PHPMailer/src/Exception.php";
include "PHPMailer/src/OAuth.php";
include "PHPMailer/src/POP3.php";
include "PHPMailer/src/SMTP.php";
 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
class Mailer{ //////////////

    public function dathangmail($tieude,$noidung,$maildathang){
        //print_r($mail);
        $mail = new PHPMailer(true); 
        $mail->CharSet = 'UTF-8';
//
try {
    //Server settings
    $mail->SMTPDebug = 0;                                 
    $mail->isSMTP();                                      
    $mail->Host = 'smtp.gmail.com';  
    $mail->SMTPAuth = true;                               
    $mail->Username = 'duongquocbien2017@gmail.com';                
    $mail->Password = 'uxqxqzwyvfzmyeyi';                   //mật khẩu   web gmail     
    $mail->SMTPSecure = 'tls';                            // cổng
    $mail->Port = 587;                                    
 
    //Recipients
    $mail->setFrom('duongquocbien2017@gmail.com', 'Thế giới phụ kiện');
 
    $mail->addAddress($maildathang, 'Bien');    
    //$mail->addCC('duongquocbien2017@gmail.com');
    
    $mail->isHTML(true);                                  
    $mail->Subject = $tieude;
    $mail->Body    = $noidung;
    //$mail->AltBody = 'ssssssss';
 
    $mail->send();
    echo 'tin nhắn đã gửi thành công';
} catch (Exception $e) {
    echo 'Tin nhắn không thể gửi đc! ', $mail->ErrorInfo;
}
    }
}
?>
