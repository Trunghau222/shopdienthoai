
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admincp</title>
	<link rel="stylesheet" type="text/css" href="css/styleadmincp.css">
	<link rel="stylesheet" type="text/css" href="css/fontawesome-free-5.15.4/css/all.min.css">
	
</head>
	<?php
	session_start();
	if(!isset($_SESSION['dangnhap'])){
		header('Location:login.php');
	} 
	?>
<body>
	<h3 class="title_admin">QUẢN LÝ CỬA HÀNG</h3>
	<div class="wrapper">
	<?php 
			include("config/config.php");
			
			include("modules/header.php");
			include("modules/menu.php");
			include("modules/main.php");
			include("modules/footer.php");
	?>
	</div>

	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="//cdn.ckeditor.com/4.16.2/full/ckeditor.js"></script>
	<script>
		CKEDITOR.replace( 'tomtat' );
		CKEDITOR.replace( 'noidung' );
	</script>

</body>
</html>