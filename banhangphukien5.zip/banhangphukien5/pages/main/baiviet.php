<?php
$sql_bv= "SELECT * from tbl_baiviet where tbl_baiviet.id='$_GET[id]' LIMIT 1";
$query_bv= mysqli_query($mysqli,$sql_bv);
$query_bv_all = mysqli_query($mysqli,$sql_bv);
$row_bv_title = mysqli_fetch_array($query_bv);
?>
<h2><span style ="text-align: center; "><?php echo $row_bv_title['tenbaiviet']?></h2>
    <ul class="baiviet">
        <?php
        while($row_bv = mysqli_fetch_array($query_bv_all)){
            ?>
            <li class=f1>
                <h4><?php echo $row_bv['tenbaiviet']?></h4>
                <div class="f1">
                <img  style="style=width: 400px; ;"src="admincp/modules/quanlybaiviet/uploads/<?php echo $row_bv['hinhanh']?>"></div>
                <p  class="title_product"><?php echo $row_bv['tomtat']?></p>

                <p style="margin:10px" class="title_product"><?php echo $row_bv['noidung']?></p>
            </li>
            <?php
        }
        ?>
        </ul>