<?php
 
  if(isset($_SESSION['cart'])){
  	$i = 0;
  	$tongtien = 0;
  	foreach($_SESSION['cart'] as $cart_item){
  		$thanhtien = $cart_item['soluong']*$cart_item['giasp'];
  		$tongtien+=$thanhtien;
  		$i++;
?>
  <?php
  	}}
  ?>
  <?php $shiv = substr(str_shuffle(str_repeat("01213456789",6)),0,6); ?>
		<table border="3" width="50%" class="table-login" style="text-align: center;border-collapse: collapse;">
			<tr>
				<td colspan="2"><h3>THÔNG TIN THANH TOÁN</h3></td>
			</tr>
			<tr>
				<form id="abcdc" action="pages/main/thanhtoan.php" method="post" onsubmit = "return(validate());">
				<td>Tên chủ tài khoản</td>
				<td><input type="text" size="50" name="email" placeholder="Nhập..."></td>
			</tr>
			<tr>
				<td>Tên ngân hàng</td>
				<td><input type="text" size="50" name="tenNH" placeholder="Nhập..."></td>
			</tr>
			<tr>
				<td>Số tài khoản</td>
				<td><input type="text" size="50" name="stk" placeholder="Nhập..."></td>
			</tr>
			<tr>
				<td>Số điện thoại</td>
				<td>
					<input type="text" size="50" name="txtsdt" placeholder="Nhập...">
					<input type="hidden" id="sdt" value="<?php echo $shiv; ?>">
				</td>
			</tr>
			<tr>
				<td>Số tiền</td>
				<td><input type="text" name="giasp" value="<?php echo number_format($tongtien,0,',','.').'vnđ'; ?>" class="form-control"
					id="formControlDisabled"
					type="text"
					placeholder="Disabled input"
					aria-label="disabled input example"
					disabled></td>
			</tr>
			<tr>
				<td>Nhập mã OTP</td>
				<td >
				<input type="text" size="39" name="maotp"   id="textopt"  placeholder="Vui lòng nhập mã otp" >
				<input type="hidden" id="maopt" value="<?php echo $shiv; ?>">
				<button ><a style="text-decoration: none;font-size: 16px;"  class="btn btn-outline-secondary" href="index.php?quanly=TaikhoanNH">Lấy mã</a></button>
				</td>
				
			</tr>
			<tr>
				<td colspan="2">
					<div class="giohang__back">
							<input type="submit" style="font-size: 24px;" value="Thanh Toán">
							<button style="font-size: 24px;"><a href="index.php?quanly=cachdat" style="text-decoration: none;">Quay lại</a></button>
					</div>
				</td>
			</tr>
			</form>
	</table>
<div class="card" style="width: 18rem;">
	
	<div class="card-body">
	
	  <h1 class="card-title"  >
	  Mã OTP :
	  <?php
			  echo $shiv;;
		?>
	  
	  </h1>
	  
	</div>
</div>
	<script>
		function validate() {
			var opt=document.getElementById("maopt").value;
			var textopt=document.getElementById("textopt").value;
			if(opt!=textopt)
			{
				document.getElementById("textopt").value="Mật mã không đúng";
				return false;
				}
			}	
	</script>

<script>
		function validate() {
			var opt=document.getElementById("sdt").value;
			var textopt=document.getElementById("textsdt").value;
			if(opt!=textopt)
			{
				document.getElementById("textsdt").value="Không nhập đúng";
				return false;
				}
			}	
	</script>


<!-- <?php
    $shiv = substr(str_shuffle(str_repeat("01213456789",6)),0,6);

    echo $shiv;

    echo "<br><br><br>";

    // $pass = substr(str_shuffle,0,6);

    echo $pass;

?> -->

<!-- 

<?php	

// if(isset($_SESSION['dangky'])){
  ?>
  <button ><a style="text-decoration: none;font-size: 16px;" href="index.php?quanly=TaikhoanNH">Lấy mã</a></button>
   </div>
<?php
// }else{
?>
<td colspan="8"><p>Hiện tại giỏ hàng trống</p></td>
<button ><a style="text-decoration: none;font-size: 16px;" href="index.php?quanly=TaikhoanNH">Lấy mã</a></button>
<?php
// }
?>
  }else{ 
  ?>
   <tr>
    <td colspan="8"><p>Hiện tại giỏ hàng trống</p></td>
   
  </tr>
  <?php
  ?>

  
 -->
  