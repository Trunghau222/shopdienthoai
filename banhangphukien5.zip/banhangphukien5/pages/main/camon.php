<p class="camon" >Cám ơn bạn đã mua hàng ,chúng tôi sẽ liên hệ bạn trong thời gian sớm nhất</p>
<p><a href="index.php" style="text-decoration: none;font-size: 20px;">Quay lại mua hàng</a></p>
