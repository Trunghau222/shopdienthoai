
<?php
	session_start();
	include('../../admincp/config/config.php');
	require('../../mail/sendmail.php');
	
	$id_khachhang = $_SESSION['id_khachhang'];
	$code_order = rand(0,9999);
	$insert_cart = "INSERT INTO tbl_cart(id_khachhang,code_cart,cart_status) VALUE('".$id_khachhang."','".$code_order."',1)";
	$cart_query = mysqli_query($mysqli,$insert_cart);
	if($cart_query){
		//them gio hang chi tiet
		foreach($_SESSION['cart'] as $key => $value){
			$id_sanpham = $value['id'];
			$soluong = $value['soluong'];
			$insert_order_details = "INSERT INTO tbl_cart_details(id_sanpham,code_cart,soluongmua) VALUE('".$id_sanpham."','".$code_order."','".$soluong."')";
			mysqli_query($mysqli,$insert_order_details);

		}
		$tieude = "Đặt hàng website thành công";
		
		$noidung ="<p> Cảm ơn quy khách đã đặt hàng của chúng tôi :<br> Mã đơn hàng :".$code_order."</br></p>";
		// $noidung ="<p> Cảm ơn quy khách đã đặt hàng của chúng tôi :</p>";
		foreach($_SESSION['cart'] as $key =>$val){
			$noidung.="*Tên sản phẩm :".$val['tensanpham']."<br></br>
				Giá tiền :".number_format($val['giasp'],0,',','.')."<br></br>
				Số lượng :".$val['soluong']."<br></br>";
		}
		
		//$diachi = "Địa chỉ : ".$diachi.";
		$maildathang = $_SESSION['email'];
		$mail= new Mailer();
		$mail-> dathangmail($tieude,$noidung,$maildathang);

		
	}
	unset($_SESSION['cart']);
	$tenb=$_POST ["b1"] ;
  	// $tenNH=$_POST ["tenNN"] ;
  	$sdt1=$_POST ["b2"] ;
  	$diachi1=$_POST ["b3"] ;
 

 $sql2="INSERT INTO `tbl_nguoinhan` (`id_nn`, `tenNN`, `sdt`, `diachi`) VALUES (NULL,'$tenb', '$sdt1','$diachi1')";
 mysqli_query($mysqli,$sql2);
	header('Location:../../index.php?quanly=camon');
?>