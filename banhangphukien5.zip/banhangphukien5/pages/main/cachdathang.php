
<form action="" autocomplete="off" method="POST">
<table style="width:100%;text-align: center;border-collapse: collapse;" border="3" cellspacing="2" cellpadding="1">
		<tr>
			<td colspan="2"><h3>ĐẶT HÀNG BẰNG CÁCH</h3></td>
          </tr>
          <tr>
               <td> <p><a href="index.php?quanly=thanhtoancod">Thông qua vận chuyển trực tiếp - COD </a></p> </td>
               <td><p><a href="index.php?quanly=TaikhoanNH">Thông qua tài khoản ngân hàng</a></p></td>
          </tr>
     </table>
</form>

    
