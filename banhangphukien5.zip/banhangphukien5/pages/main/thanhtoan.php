<?php
	session_start();
	include('../../admincp/config/config.php');
	$id_khachhang = $_SESSION['id_khachhang'];
	$code_order = rand(0,9999);
	$insert_cart = "INSERT INTO tbl_cart(id_khachhang,code_cart,cart_status) VALUE('".$id_khachhang."','".$code_order."',1)";
	$cart_query = mysqli_query($mysqli,$insert_cart);
	if($cart_query){
		//them gio hang chi tiet
		foreach($_SESSION['cart'] as $key => $value){
			$id_sanpham = $value['id'];
			$soluong = $value['soluong'];
			$insert_order_details = "INSERT INTO tbl_cart_details(id_sanpham,code_cart,soluongmua) VALUE('".$id_sanpham."','".$code_order."','".$soluong."')";
			mysqli_query($mysqli,$insert_order_details);
		}
	}
	unset($_SESSION['cart']);
	$chutk=$_POST ["email"] ;
	$tenNH=$_POST ["tenNH"] ;
	$stk=$_POST ["stk"] ;
	$sdt=$_POST ["sdt"] ;
	$giasp=$_POST ["giasp"] ;
	$maotp=$_POST ["maotp"] ;
 

	$sql1="INSERT INTO `tbl_cart_nh` (`id_cart`, `id_khachhang`, `code_cart`, `TenChuTk`, `TenNH`, `SoTK`, `SDT`, `SoTien`, `OTP`) VALUES (NULL, NULL, NULL,'$chutk', '$tenNH','$stk','$sdt','$giasp','$maotp')";
	mysqli_query($mysqli,$sql1);
	header('Location:../../index.php?quanly=camon');

?>