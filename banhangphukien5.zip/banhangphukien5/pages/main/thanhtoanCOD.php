
<?php
  if(isset($_SESSION['cart'])){
  	$i = 0;
  	$tongtien = 0;
  	foreach($_SESSION['cart'] as $cart_item){
  		$thanhtien = $cart_item['soluong']*$cart_item['giasp'];
  		$tongtien+=$thanhtien;
  		$i++;
?>
  <?php
  	}}
  ?>

		<table border="3" width="50%" class="table-login" style="text-align: center;border-collapse: collapse;">
			<tr>
			
				<td colspan="2"><h3>THÔNG TIN THANH TOÁN</h3></td>
			</tr>
			
			<tr>
			<form id="abcdc1" action="pages/main/dathang.php" method="post" onsubmit = "return(validate());">
				<td>Tên người nhận</td>
				<td><input type="text" size="50" name="b1"  placeholder="Nhập..." required="required" ></td>
			</tr>
			<tr>
				<td>Số điện thoại</td>	
				<td><input type="text" size="50" name="b2"  placeholder="Nhập..." required="required" ></td>
			</tr>
			<tr>
				<td>Địa chỉ</td>
				<td><input type="text" size="50" name="b3"  placeholder="Nhập..." required="required"></td>
			</tr>
			
			<tr>
				<td>Số tiền</td>
				<td><?php echo number_format($tongtien,0,',','.').'vnđ' ?> </td>
				
			</tr>
			<tr>
				<td colspan="2">
					<div class="giohang__back">
					<input type="submit" style="font-size: 24px;" value="Đặt hàng">
							
							<!-- <button style="font-size: 24px;"><a href="pages/main/dathang.php" style="text-decoration: none;">Đặt hàng</a></button> -->
							<button style="font-size: 24px;"><a href="index.php?quanly=cachdat" style="text-decoration: none;">Quay lại</a></button>
					</div>
				</td>
			</tr>
			</form>
	</table> 

	

<!-- <?php	

if(isset($_SESSION['dangky'])){
  ?>
  <button ><a style="text-decoration: none;font-size: 16px;" href="index.php?quanly=TaikhoanNH">Lấy mã</a></button>
   </div>
<?php
}else{
?>
<td colspan="8"><p>Hiện tại giỏ hàng trống</p></td>
<button ><a style="text-decoration: none;font-size: 16px;" href="index.php?quanly=TaikhoanNH">Lấy mã</a></button>
<?php
}
?>
  }else{ 
  ?>
   <tr>
    <td colspan="8"><p>Hiện tại giỏ hàng trống</p></td>
   
  </tr>
  <?php
  ?>

  
 -->
