<div class="clear"></div>
<div class="footer">
			<!-- <p class="footer_copyright">ĐỒ ÁN WEB BÁN HÀNG PHỤ KIỆN 
			<br>
			</p> -->
			<div class="grid">
				<div class="grid__row">
					<div class="grid__column-2-4">
						<h3 class="footer__heading">Chăm sóc khách hàng</h3>
						<div class="footer-list">
							<li class="footer-item">
								<a href="" class="link footer-item-link">Trung tâm trợ giúp</a>
							</li>
							<li class="footer-item">
								<a href="" class="link footer-item-link">Hướng dẫn mua hàng</a>
							</li>
							<li class="footer-item">
								<a href="" class="link footer-item-link">Chính sách bảo hành</a>
							</li>
							<li class="footer-item">
								<a href="" class="link footer-item-link">Tìm hiểu về mua trả góp</a>
							</li>
						</div>
					</div>

					<div class="grid__column-2-4">
						<h3 class="footer__heading">GIỚI THIỆU CÔNG TY</h3>
						<div class="footer-list">
							<li class="footer-item">
								<a href="" class="link footer-item-link" >Tuyển dụng</a>
							</li>
							<li class="footer-item">
								<a href="" class="link footer-item-link">Cộng tác bán hàng</a>
							</li>
							<li class="footer-item">
								<a href="" class="link footer-item-link">Gửi góp, ý kiến</a>
							</li>
							<li class="footer-item">
								<a href="" class="link footer-item-link">Xem bản mobile</a>
							</li>
						</div>
					</div>

					<div class="grid__column-2-4">
						<h3 class="footer__heading">TỔNG ĐÀI HỖ TRỢ</h3>
						<div class="footer-list">
							<li class="footer-item">
								<a href="" class="link footer-item-link">Gọi mua: 1800.1060</a>
							</li>
							<li class="footer-item">
								<a href="" class="link footer-item-link">Kỹ thuật: 1800.1763</a>
							</li>
							<li class="footer-item">
								<a href="" class="link footer-item-link">Khiếu nại: 1800.1763</a>
							</li>
							<li class="footer-item">
								<a href="" class="link footer-item-link">Bảo hành: 1800.1064</a>
							</li>
						</div>
					</div>

					<div class="grid__column-2-4">
						<h3 class="footer__heading">THEO DÕI CHÚNG TÔI</h3>
						<div class="footer-list">
							<li class="footer-item">
								<a href="" class="link footer-item-link">
									<i class="footer-item__icon fab fa-facebook-f"></i>
									facebook</a>
							</li>
							<li class="footer-item">
								<a href="" class="link footer-item-link">
									<i class="footer-item__icon fab fa-instagram"></i>
									Instagram
								</a>
							</li>
							<li class="footer-item">
								<a href="" class="link footer-item-link">
									<i class="footer-item__icon fab fa-linkedin"></i>
									Linkedin</a>
							</li>
						</div>
					</div>

					<div class="grid__column-2-4">
						<h3 class="footer__heading">Vào cửa hàng trên ứng dụng</h3>
						<div class="footer__download">
							<img src="" alt="">
							<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAgVBMVEX///8AAAD+/v5ra2sxMTGtra3m5uZUVFTx8fE+Pj75+fnW1tYXFxeioqJiYmKYmJi+vr4gICCCgoLIyMiNjY3Nzc1ISEjBwcFnZ2fy8vKjo6OJiYl8fHwUFBScnJxeXl42NjYoKCh0dHTi4uJWVla1tbVGRkYcHBwkJCQLCwssLCxiXH09AAAeLUlEQVR4nM1dCXvUPK81gu7QDt3XKbSUUv7/D7wTK5aOFieZlvd7rlgmkzi2j48syY7jKYWoUOG/9Wg8qEftnLk0KeNtZJKRSs0aP1ppctQSzolWpdUMaokpxmw1GQLKc0Qs8ftYEC1oDluZTmJJ4ZL0jk1ybT6TCOoqnBRpcTwvtXMZdOsi2Iu0rU05qhPF1pSGs8VKCzSqlM359n23xGrYs/9hgenVqH5C3NggY7PWIz4pbV2g+yBD4wnsGtisTSeo1SAhk7A+aBBIzITkpUhHOFKH5e1K4SB8CW00meh/JiTtUr+NRI1NMKYo2v/0tnYSmkyvjJ1VO3LBI+UfDYmvUwnXo0lXjTJ3WsMZCwhtYAxaTmZyz5J0y+RjOUBzmEYFZNhwYoDtDarw2LjaLXw9M+YmKznxPZhdIdb1ZcEDdsbpRMgz2nRf0lQ9J2TK9W2XLfnmtMbPZ0JddJ3M/3+IaJkYfTHH+h8fELRhMC5jSDDe2aw2ya1p26et0FKjfps+YVJ2Qfk0ISl6t/G7vS/rDb5NpgtfLh/SB+8D7DHEZFSApDQPq9fQPOBTvHEuYI+sUTIWIXanUMdYI0iEKGLF0UC58jrS18D52/4h87YySVcRgHxZuphJ4sYS0BKaKUkenSZseWkm3rubiN10bt9rc/XDvNJWwFJSLbXKk+fXtwrzigEaPt1OMWfkME0Uclukp9uI62E+Y70cuyK5enS6J6myNU7V5rdronja/02bAnEkWYzjC+tVTO0IKuOHOWSgtGGNYnGGKbRL6BWJTi3RvZjDVJKJ2zpfk2sTFim/J4Sk7Ys2HHzTEqAPK7fyjSQTVDwow/aSopn5aR4PLtzVhUa2PA8z6x4LR5RYgcXpw2E34TtUJL+FbItamyQsNUJNLxIfolZ+qgpgEhZA7JiiWRELsTB9v5RODsEo/zfiDa73lk1Orj8vlPuY/dNw/vhZMzq+qMc7w/H1DqQ/OvbZPWF290srcb3euiWuPy2Vn/Hmh3rhqB4/1uNVRX9Xj++gLc5ifthePxfX4jqYK2zyzLp/Xpz3l6LKPQ68vo8Ih3PHgrCU83p8DsVEhF8F3ubfl8W1+IyAZvsybY3Q+YWGsHwEYXkPwi48G7VszSFhbwYO34lQzd1WCOeNtsG/JYc26zdAyB36ChDeTSJ8/TCHBkxqwIHDp5edCVkrwnJ4D3JbL9fDU67k4+nw5byev4Aid+uZc6jqG2dxCAjXU5V4eQIONfyqQGJAAx+M8CVpGageI6x37WOD7tfLP0JD3yaNPMhR5GQfEO5O1uJlgsNMa9s5RrjjzsJXEoSlg/AgVPtbKGYrhN4dcPffQYR2LlR6piWTq98QupGTCc6EwxIQDsmmEEJdNyl7CKkhHKOtFguauMsg9G0gdY0xl+UQ26csQTjIPMKW3TyHfgQCFe5wCNMgoK+k3xOEoZW0H9IyhGufyRYcdsUjJMNhKFFEEG5Onp14YeTSDzdyuK7CfuJ8vUmz/gMVfvq2uXjC/uOiZnEFhSHCN87o0CCsSEItzixCfFiv5BmTKm1KFuFJaOHLmhoRjvI1slEF8bCTuYdiESFGbcAhlcuQ6YlBGKJRcu7CiWopJQj3AoczCFeQ5ls9cwrleoTNBhoO92YQqpWUh15hcqcFlhqXsjbmCJFDidpmEJJHOMHh1giRw2ZO/GAxRG09LfUIl3NIilAfE0eEo8VALc0RktPS8Sn26F3cXJLUYRmHxlu0TDoATT90HFLQUqnP9hxaIJhVwyYP1mY5NN5C7NjJ+UZOHiDpUz31rQa4R/W2i/OaqJ65Kss4pHkOBYD76MmWHFpBP8Fx9mk9Rn94Vc88ZhwqCx/iEDOSDtFCI4zaeraU0OMTGK02PmQ5A4Tf1I6XVT1z3OGwWG/RRWjjUjfhjhz6qA0Q9rwFGW9hIymPkBSh9I5ZhJbDnpZab9ECGg1irTFF1LNaSmQtDeYzzyEg/IdaOtZEYxrnDY3MWxqrpeZm9BnYD7+V8UnNHIe02FtEDse7Yb2nF67wtpbmcPWyWtV/m//qfOnTa718PpxaPTYORZZwWD5macRDCLPwPGze0lgttWOLm5p1NnoiCZqm+yH5qG2eQ+mC8kHaDxtiWMs33w8nZzGog3ARh2Pt3mNLSyminaKhamZAk7fW0sUj4FZcQ0iRwyymWdAPwcSoSdWzXn/n/eH0LEaZm8VQLe30w0X+MCBk7pEtZFHBbxXTlJRDmplru5pDOMjWHCoMy1jCJSLcudxzcho4vPm1Of3rV0M45Pbk79o7uVDhZts7Go5fhgJ+7U0h3Dgcn9vljkFop+DIO0LqIeyHrpTFpa/CYSY484vCanAzzWGnEnYErGEngJQYR28q2Vxb7LAJwq+gpSa/SYQH9er+NIc9cf4QiiPbEwU521qMSwPx4zGOngJCiJ2ad5tASDJdl0ZtYhhJK9Q8q2gpgZ+AD+ckJFrtzCYaIs0Yn68AwkT+FxxOCVjSLkIjSVz65hCSOVqC8O29CEnipaZ1YW22AcsI17tTcgEcEp/au9zIwVE95sdH+3DMCH8OaS7Zl7wOh78fa6Kjg+HLHmdEgPBishZr5bDhab2ifaZ2aovnhzWH0R/yzXx8VHNnBxKfkPKTw+t6/Bxv5sBvy+eHY58Hv5FMYzTA2z7lHhEyV0ueAceY5ns9PmwIlcOFCI0xaRx2CNyaw3+GkAxCesczYOct7NiC4GMrhAQIqYNQLc1yDrdDKHYehsHG1Fmvtxzh38jha4LwPVpKf7dBuEykn97//LJM/l7WG27ql9fnwbrtHwzH38/q8ee/w3meET75szn+eTdYzv2X78PNn+vxVYZwaOrLvwtr8fO+RdfIVZjDIGG4FJghlLuai9EOrfPmo93i6vEULvuDM9Gb9slz3vc1B1yLkViadGiHEJrF7IfPWPJsqv7dcivGNAeK0MhtPc/DE4+QDIfvqgZEluk8FN7gv02XWa8uQajPLWY5XFS1WQkDJ82G7BdyzZSIIKQFCGmeQ+/jQhUdEOcROlrez4ayk+bW7TiMCJdwSK715yRYH775Zn8QNv6H4fiGre54TNrvGeHzcPehIrSWgPvh/ZDTDfuMTzVg/1PP7CpCsGib/6RGYli0XmoDCcI2Z+EAshk9UZunQTf2qx7bETD0Q5YLOtwIBeb59AukPCjDqV040zgEs8GTHCuwCH5BQJ/DDGiciTqvSbhifq5NTDYiPNImSwpZGYSDJJNZOnhtCId1aM1jKUISPcIitHHbMps5hAQIh2OcER7FIjQO1iAkh5AonVRW86YINS/HYa9n2hUZ8gVWfQHC1vTJU+6opUeQbxTHYUTopWmpZhi1tGdAxdzA3XG1CfZDwyFmlCPMmnAbhMDhCnLK+6H3F/q/TXDcOCy2HwqH1Dg0S15nEIIgwr/1jLE0N6HevGII14OeRIQZf+jLYabx8JANoebEWor9sBrFw+dPX1W4eruH1ooOq/SHizznfVtv4NUMx1wQF1sPedbU5MnzpZzw6W0481IkPe3UrJ9gZBTN95xkWqpimt6pmOSvT7mbx/80IvRyGLPDGWHsPSzJfKmx3YTfm913yCcQUgchBAEzCKHlmZgUodRJ/XQb5kzPJjrXX3JWM2+hqXMOW8uRQ0gZh5BwEiFls5xubeL45DAA6UeqDuF2Wiq5T3OIRHa0tAnMxY/R29yMcAtFLTaLEycfeDj+C67uxyrtYyhaj+7rebY0OwmHatsXIUSLKivZQ0TesqXiuRu+PT18//59tFk3u0OEe/u2OfOHreXbn+9NXg/q1WfP4caBvQ5Z8FoMzuJuyPQPrgk71hLbQU25O76yUY/52vHXzc1vOzXaPn+Q8scawdM11/ncI2/XVqjvGCqj4KMx4FBHT2rJ4qz+cTHlS8pDyx5G3nlGn6GvOkva0I6ENu3u9egEYc2k+xz/bGzIHkIrTldRP2VsQR2EHd/Xnil6I2P8Dk0iLClCUoTSD3KEmZVThGKCFGH2mO6zZkJqS3PL6RG2hBMc+qBy13DYeMkqdhwCYodQr81zmAsZh6+YYQQ8nuohNJMPLL1ZjFix6169MCMWfsSDr4i5poJ2Iul4aniU4xJWfbHsH+Vy9uNgEIuQyHJ4UhPxutOn5+E29opfDzpyUfPegzNsgv8Ohz/W9So72c81u+dW/2K1IrgQ4dJGR1Nzrqk/JOyH4vFZ0LF2hccWvVl99od+SbzQ1e19BP/FCLd3ZycutVpqEQ7ZrOJtNouhuN6TGZ4/wlkMqR5ZDguoJzjd0n8rKFLejdr+W4RFEWLF7RAK/aF1uFPP8T2P70BYliCkxQgn6jhGpHBBGD2WnDRczyXph7j6ElfQIsKZfojvkE4jPNW6C3mybia1MSxHZ4PsQoNc/TpO5fOZl4vr4fw1B4yXw/HjbT3PivFjuPx4dzGcWUO1Xy80iyvOm+3nC2T9KyD8UrM76RGg4EFjc9g9f/g3ZhnfnIlujJv+As78wTLxZozdngJClmupes6hRUgFns+N40maidqMfA+JVjX/iDA+tyhxDNUiG+vFLMKZMX5yKl6Zjrzfg5ACQmqrCxzCIkYcLeA8wqiP8HzjnyMsSzhseUWEZQ6hj9FwDLVMeuPD7zHp2zKEjsNPWC/MIiJ8SRAulYy9q/vTjTyGav84qy8f1KunbN7v6nF9KeGMTf3J1fBlt9MP91cqbI0OObuMwyIIH2uamvXVqXCoGCIqAZf6vbgKmuWSK8lfGCEfo8fHHRQih1EWzdOwLH+zqydNs6cR7iLC6WfAkUMoa/z7MYSpEfGnbAQ3fPsnCIeMOghbMFL15wMIx7kEN1s6Z2fey6EbW3A5ExyKTCBUS5MjLEVnhS1zU7MZZRahWfj6qSEsRVcMSd9GhDDoKTgKTRFqgIK7OzHCbOcPQZYCY7w7d+cqt9+s3LL9+lkvjmavpr/jy3zvyXDbmgl4ufMZ8dj/uZ5fa9kN4XqT9Pbb98DhCmrBlXsUhE3X4Ym3oPVjJ9tWcR+tZJsHFs4Dd8LilsQ5bxT2hz8ghhwR4tii7fzhlS16/BGIhdgR1PeIEANmI3F9KQs+t4gID+BMsvpyFzoSVtwhtGufRajzxSF00eqHEGKY3xDqiDxZI2z2p4FRoOfQIHBjfIvR2yzmUNpo83dLhPQeDslwmFnFJGrzEQvZBsUL01ra7YeHNTfcCYtlDqHqSK6lSQ0pjg8VFMzZaCRuWY5aerReYEuZw7rJwClXbKVm7+4CMjqDyPugyIi0HLLVPTQcDlde1IqujwDh75r1zkiWGBlAaSgtHYQlGz0l/jAKG/Pe7i1RSw1RyCHu3pLM04R7y8RIcDuEENNkmelK9tbz4+rLA2htMxnYe/+QV8FAU5koTfLBl2ZC3d6DkLSQiFDPxtWXB1AzrGf3bfWAEAuWyRflMKtZ7IcLOMwE1+r3EbpwOXJYAkKyHDZcTJ08+YWIxkmMaab74ackk1po291T7TgivFAOM0Ettf1QOYStfMbACN7Nc8ENVvJ2GETfHQDCCx58VxknPmGMf1/H9SvOog7rV/ua0T16jrN7HaCfNA597MHD/j/A4VqLv+dhNSN8rKVd+NdjivqLTv+pApuumGvoD83zQxzp23VtYMS5FSALiWlazeJMVBaKoT88Rv+A0vUWLPfAIRokjGlm3nvqSVxBC2Ywn2vzMj0ThWMLF3TCN4tQr3iENI8QvcBw4BGS0aXIYSFrHnOE0APVI/pa4MFShLMcRn/U4zCZywgcjlZrikNtCI/QXlGEth8gwp/IIXUQStWkQNsPW9NJwpRDm0PKoULxSM0JwYgc7sLTJTb4r/UZ01O9elOfFT1e1QdE+O7aEdy2qxld4NTIl/rUiQ0k8bOnyCE28TNn8Tg84vodEVJpXjH1hNgKiLDnD03ZeJkR/oIza3DUiUQbIwiVuqpMvG12f56mdXvVR2rAMQXREoQ28IuroI/hTFx9iZIsW2kI29i0mZDzESGVZNcITQkLLJKHpfWOZRyCzCIskwi7HDppCLVembfAP/aKfoKlyRHqAJP/eYTkEA6NOsXhxPpSpGUCIRmXD9g0IEd1RQ7jsyfLYS0aHxlFDttK9lx40f8/4rBvYdqVutDo6H5YyvTjvB6v67ImXMNz8AxLo7iJfusapr/PgPBLXcp0UlPeBQhv9bZL5JDz4Aa7Cuuw7qBe5w1h83Xg7nF4WAj1ANdi2JXs3SUUyegJMjqDpo/yG24yAW7cxIdl/vnhGKJOSP5m18QymEPUAGk+MiPgib1NxAsvelsdx4cOIZCHHDbQWse4qyCu1e8gBMMlQaEgTJeFNoRjs5R0NnEhwgYKZ6O6/THbr+28Jp/mUJtKDFl8Hz9DKI28nMOelvrBvXp8qWD9Pv123gRC63Ebwt6y0IZQNXxEyMuqttPSMLKnwKJ0z3Gt/tstr4wfEQ6JDUJesW8RQlsW1dK6xP6GB9QPf3SJPSBsq/T51HM9Rsv9Wlfmv40Ii3BY3xt4eFIII8RJM+P84acR4XAjImR/eNMQhl4IthSF3RiuwmCEyRJAFHavbU2UcpjPl2ZjXhygNrEIB3EIKcy16fiFO2JEGI1y8pZslIuC9mHIOqwvHRtX27lDHKCMCLFivdlEdb0lR0gB4ZB+AcJsxVCbEYZhH/ClQaViQxqdlpagpRTmvMmVtpBDWsAhdRC6YW/aB3u9cksOZRDe3oNZrKUf5VCpi4N7Q6BGAfzG5r2+y/npnOA1+tfNmbe9Iu+QPrxKP5QRC3qLh5oHG8K74TZawZukjUN4DTXKGeE7pIN8q2+Pniow1EHnKQgrVzTY6r0VhDsOmPeAo/Q8vnv2JHVJxhYo2e/COC1VoBMxzdx7T2ZPhVBeKwG8xfTaxC0Q6rvcvvLT/s8konmEcU+F2GJjF9gOYToCzhBia/o++B4Oh8RTCF1vbv5ikIUIReYR6rxCXDdjHeM4xLBji5bIvfdEsxz2ZBuENM/hxO8zWac3Quwn91oaOCS3fym/wF/gmE/E3cwEIRktHZlfwCFhAVJQKRKSCmNESKClUXeDafrMu8Hst/1phmSwP43O6pP95YDVjWwrkyDU7W4ch883+1YO598hBQPXbIPV4Q+JQRh3nS+hYjNrE/2uEUU3YKSJ9w9FMxmuc/lGIPySmR13HUZi6bMnQDjmNrmC1mrpfjAQsD9Nj0MXl/bRbSm1KtMIR0kQYrUItBS3QOWrs1qqGdoDsLdzHmQC4rsRBunuhLUIoXFWOKtvawtodcDcDuxspOipQYjzwmdFC8OZ0nspRmfEiByHajXsHkPbvAfck632TRzqwhvC1h0TX490h1jeN5Hlz3ofLlR4F69DFhwE7j/UVICQ9018wNUmf2pGt3W7xfOI0Hh1HFyYTlplu70vRRkegorFWX0UjNriK/3j3pfZiqFB8AGI+R1S9RtwEq5uiTDZRQn3847PnqQssjFNgrC/YmiQ9BmwJcqCAri0JUIxUPg2QhzjfwtlznA4gZAmZvUx9EYKDdBtd0oOHLaCwhNSMR0GYeRwMGH464CLOIRBCpSS+od3/B4wFfu+Bcv0knhEGPfco4cRYc4hLgV4dAyibloX2A632s9b70cOr38P+3PzqoWdegOHYjvDvt0HJ7UKiJDN8bMg3OS6O24GrpbmFjK6gbrETX/8aCrncNGe7HgqvhXE0vvdtem1+kbsfm0TdYdYb9HoCUYkGvLwvebXAclqqUO4giqlCKXfJAjJefzEXCYwszTRH/4zDlcSvZD5dUA7PjQxDYT1VXBvEwfTwyFpc1J/30635GaMj2ttwQ4jh2UBh2M1uhzyMNRwCN0Jorbo3sIJC7pvS/2+GHgPZbMYbFfio7EVNBU+UDEraJHD+NAcd28pBoL2NzMI9upsvtnnh/I7M7/aT7xw2IxaerMHvzNTE16+6I/KnO1D0+7WU7f1Bl6y9VAz5i1mDiELlF/ceAc1a8ZZf55mz65+9a4+Z2eQ+V/pnPitIJYjm6v1wcmSh6/12sw8zSdoeX1uYXusDn8McneEv6STIbT9sI+w26DxcXl3TVSKkPK3EazZaJ0YgjZJMPd7T4Cw5pAiBNMEHPK5DCF4i3cgNEGMXZo4bWn+jZZqC/8jDkvCIYzIi7gfvDwOqCyHnX64QEufM+UUSZYe1fNbIOR6PU0UQgrdWqNiYpr5384bKvby8rIa/mz+XrFXfKw/gwhyze8Gra6HX0dk93Z59VKl3ooc7gxn+PQVroy6qy9APNeMnuv1I4wNzARgPk/TZFstNfIn3MAS15ea3cwIEOJ8Kb5LssLkjq94buyf2CElxYcQxp0/GkKN2liOsWgf07TKeITau6iYrgUOv5ScQ4U47y2yvaBHF9RHOIjfoVUsO3KIkbdF2OJSZywFLkFlzLMn2yvnLY3ph26N8TYIfSPPIwQ+TOsgXDOREMUg7HA4yNZaGlfQXmuRnkMJUHr9UOoKxDBQMk8v0uQLOHRaengOb8lGhKfDr3C/8K924zYwP/hXu6EOsxwOclVL4+l0/pnvHQfXSzwz5y2IKItp6s7cCcLplXs/IOZJfoXF98Nsrf61+niISB2H5ss7Y5oeh3OrL7fkcG6dtxsopYR+ACG9A2GzC+kshkNIOUK1O3a42JN3/lruf8BhZmnmOcxEHAn5EXBEeBksjXmzK8Y03PRxlX5ESNhULHY6hFIOj8GlQpd0pja1pRs5O/GyEzg85AvrQW55Ivd0rTc8+4zWT1Dtn7drFT5VczoZJ1jrDV+AwzMo7bwevhggLYZL1ZRcP+wQDgjxPDIz/Q7pzM6QLPguCc+Q4GqT5DdK2ni0FMPZ3PjQQIfskpmo/HdmTLuM3WFmd09AOBZsf6Nk+GMRRj1MLE3u8Umap8Ueo753fy1XEE6YsuUIR9GVCs1eGoShKDt/MuHx8waoMo+wI4MF2IbD+p9wKNFZvmvEUok79EdZgLBf8qJ+iF4ROBwl7DhgwrY2joCPJKZ5GsLJrqwB4SGfYiv6dL+RJ1axq3oeZzSO6hl+M+HL6SblafdR3hpKO62Z6gRe4/BXraMu+ejHaVbe+UurLDhAb7tGaHlx4xzzwwo9ke0JpdZux4FJcT2S3v1Lqyz7Yo/6O39gxbpbFqUIReZ2HCAJY/reYilCSh7Cj2IR0kcQyizhIoQ9abd/lMMOwhIR0lYI0et138eXcfBUP7zuluTlZ0SIbgz7YUT4uA2HjoTOTlhLZMji5PrzQmGPewNnHpHDmtExdqLVsc6gcvD8fBxyDXJ8BEOjMSyCjGARhD61nuTwYxJjiV5hNGnRs2x1+NcpUmKCtrAlJpiuU576Y+Kr10sFPbGXZnJttyllVAfzqApmQlpR8lFiMghhO/XCiUDKBzsy3pP/SIvNG4SaKnfhSp21gG1ke8V7x7V3Zu0CHmzeUgwl3RwpfFcWfaE2ikTWe4TDkjHDIcF1TTbxZMYbohbNwx2+rqhjoRG6ZIQxXWyg3o3LZCKmaU0gzzhG2DAV2SnZcI911ZP+uLjeq4+nDVR7p6yrgatoJHR5qerQTHOouibJJ71PNIFQNpE0pqYhwGvtmWoTueYm/Wj30iSHUDdNZaqRJwfEeIX8QzGvks70mkaB/oJa4sv2Rtze7bq9RnZGf1rLSDvaNivBnmuDA6CgmdDgxsuQxTTqD0zdK1hzA5JswPlGyRRrUrqdU1pL8CHY0Dm1wmMNtWcQ5FfwbMHbooroVZfYtw0+motqYtpGy5boCQAoBsfZaOgNYsI7VZ2wAWyfBcXylUsIMPosjZn0ApcLtiHqTOBQFF+codN7VcvWOmLlVW+VgkKxlKxe4P1Ci4ICeaCauWsbxYPnoLMazQRzYzI3XQ4L1kYSHZNEwTou6XHWlBHUN3OYWDC5BiVk2GJFglXXAYggNn2puCyWILJqFetp0gkthkwhRfKwAbxhBvlEBz+2rUZmpp1azqHavkc5PXS9HCqoqmD1Epuv1YREv2zkiX3Odga4nUxqMAWtS0pGtlUsMwEofpjqNKwhMGvtE9tM6wJmkPSM9V9Wc+XDMoZNrEYoUS4q4VyKFrEkChpozA1Z1ivIfk8azX+JEIqwbZSgVUmy7JgprBt1LttKCGHtjCEJ6qH/QE+LsCgXwR8UxzmyDGa01cG1CbZeg4KdBHXdqD84VoWJnCYMaA/tScvf5ttNKDYodEbytQBfGgtTpvEiuUy0NtqxWmMhfuiYypS1M4Yy4L55d6N5em/D0m+87ITR7q6uCsvxGho4wj/kUkuLUvwgk8q3Zgom9C3toL5zqdZAlqYWWn8kxBdve5zizupodM6rnNzber/Wha//H+Ifc6X1np3/AAAAAElFTkSuQmCC" class="footer__download-qr">
							<div class="footer__download-apps">
								
							</div>
						</div>
					</div>
				</div>

				<div class="grid__row">
					<p class="footer__text">2021 --w--</p>
				</div>
			</div>
		</div>